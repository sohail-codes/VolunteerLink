import express from "express";
import { configDotenv } from "dotenv";
import cors  from 'cors';
import router from "./src/routes/index.js";
import ServerlessHttp from "serverless-http";


configDotenv();
const app = express();
app.use(cors());
app.use(express.json());


const port = process.env.PORT || 3000;

app.use("/api", router)

if (process.env.DEVELOPMENT == "true")
{
    app.listen(port, () => {
        console.log(`Server is running on port ${port}`);
    });
}



export const handler = ServerlessHttp(app);