import { Router } from 'express';


const EventRoutes = Router();



export default EventRoutes;